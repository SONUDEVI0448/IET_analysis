# Distribution of Earthquake Interevent Times in Myanmar

Data and MATLAB code for:

> Devi, S., Pasari, S. Distribution of earthquake interevent times in Myanmar.
> *Geomatics, Natural Hazards and Risk*.

## Files

| File | Description |
|---|---|
| `raw_data.csv` | Compiled earthquake catalog: 70 events with Mw ≥ 6.5, 1900–2025, within 89–102°E and 10–29°N. Columns: `Year`, `Month`, `Day`, `Latitude`, `Longitude`, `Mw`. |
| `reproduce_myanmar_interevent.m` | Reproduces Tables 1–8 and Figures 2–6 of the paper. |

## How to run

1. Place both files in the same folder.
2. Open MATLAB (R2022a or later, with the Statistics and Machine Learning Toolbox).
3. Run `reproduce_myanmar_interevent.m`.

The tables are printed in the Command Window and Figures 2–6 are displayed. No files are written.

The script performs Gardner–Knopoff declustering, extracts the interevent times, fits 14 probability distributions by maximum likelihood, computes parameter uncertainties, model selection statistics (AIC and Kolmogorov–Smirnov test) and conditional probabilities.

Figure 1 (tectonic map) was prepared separately with GMT and is not included.

## Data sources

The catalog was compiled from the International Seismological Centre–Global Earthquake Model (ISC-GEM), the United States Geological Survey (USGS), the Global Centroid Moment Tensor (GCMT) catalog and the Advanced National Seismic System comprehensive catalog (ANSS).

## License

Code: MIT License (see `LICENSE`). Data: Creative Commons Attribution 4.0 (CC BY 4.0).
