%% ============================================================================
%    Devi, S., Pasari, S. Distribution of earthquake interevent times in
%    Myanmar. Geomatics, Natural Hazards and Risk.
%
%  Input  : raw_data.csv in the same folder as this script, with columns
%           Year, Month, Day, Latitude, Longitude, Mw
%  Output : Tables 1-8 are printed in the Command Window and Figures 2-6
%           are displayed. No files are written.
%  Note   : Figure 1 (tectonic map) was prepared separately with GMT.
%  Needs  : MATLAB R2022a or later and the Statistics and Machine Learning
%           Toolbox (normcdf, skewness, kurtosis).
%% ============================================================================
clc; clear; close all;

%% ---- Settings --------------------------------------------------------------
CSV_FILE   = 'raw_data.csv';
LON_LIM    = [89 102];                   % study region (deg E)
LAT_LIM    = [10 29];                    % study region (deg N)
THRESHOLDS = [7.0 6.5];                  % magnitude thresholds (Mw)
TAU_TABLE  = [1 5 10 15 20 25 30 35 40]; % elapsed times for Tables 7-8 (yr)
NU_TABLE   = 1:15;                       % waiting times for Tables 7-8 (yr)
TAU_CURVES = [1 5 10 15 20 25 30 35];    % elapsed times for Figures 5-6 (yr)
YEAR_END   = [2100 2090];                % last year on the x-axis of Figures 5 and 6
FMIN_OPTS  = optimset('Display','off','MaxIter',10000,'TolX',1e-9,'TolFun',1e-9);

HERE = fileparts(mfilename('fullpath'));
if isempty(HERE), HERE = pwd; end

%% ---- Load the catalog ------------------------------------------------------
opts = detectImportOptions(fullfile(HERE, CSV_FILE));
opts.VariableNamingRule = 'preserve';
C = readtable(fullfile(HERE, CSV_FILE), opts);
C = rmmissing(C(:, {'Year','Month','Day','Latitude','Longitude','Mw'}));
C = C(C.Longitude >= LON_LIM(1) & C.Longitude <= LON_LIM(2) & ...
      C.Latitude  >= LAT_LIM(1) & C.Latitude  <= LAT_LIM(2), :);

%% ---- Analysis for each magnitude threshold ---------------------------------
R = struct('Mth', {}, 'ms', {}, 'iet', {}, 'F', {}, 'order', {});
for k = 1:numel(THRESHOLDS)
    T   = C(C.Mw >= THRESHOLDS(k), :);
    ms  = decluster_gk(T);                              % Gardner and Knopoff (1974)
    iet = diff(datenum(ms.Year, ms.Month, ms.Day)) ./ 365;
    iet = iet(iet > 0);                                 % interevent times (yr)
    F   = fit_distributions(iet, FMIN_OPTS);            % MLE, 14 distributions
    F   = goodness_of_fit(F, iet);                      % -lnL, AIC, K-S D and p
    F   = parameter_uncertainty(F, iet);                % ASD and 95% CI
    [~, order] = sort([F.ksD]);                         % increasing K-S distance
    R(k) = struct('Mth', THRESHOLDS(k), 'ms', ms, 'iet', iet, 'F', F, 'order', order);
end
r70 = R([R.Mth] == 7.0);
r65 = R([R.Mth] == 6.5);
LAST_YEAR = max(r65.ms.Year);                           % last event: March 2025

%% ============================================================================
%  TABLES
%% ============================================================================
print_table1(r70.ms);
print_table2(r70.iet, r65.iet);
print_table34(r70, 'Table 3: Estimated parameters, ASD and 95% CI (Mw >= 7.0)');
print_table34(r65, 'Table 4: Estimated parameters, ASD and 95% CI (Mw >= 6.5)');
print_table56(r70, 'Table 5: Model selection statistics (Mw >= 7.0)');
print_table56(r65, 'Table 6: Model selection statistics (Mw >= 6.5)');
print_table78(r70, TAU_TABLE, NU_TABLE, LAST_YEAR, ...
    'Table 7: Conditional probabilities, exponentiated Weibull model (Mw >= 7.0)');
print_table78(r65, TAU_TABLE, NU_TABLE, LAST_YEAR, ...
    'Table 8: Conditional probabilities, exponential model (Mw >= 6.5)');

%% ============================================================================
%  FIGURES
%% ============================================================================
figure2_cumulative(r65.ms, 6.5);
figure3_ks_plot(r70);
figure4_pairwise(r65);
figure56_conditional(r70, TAU_CURVES, LAST_YEAR, YEAR_END(1));
figure56_conditional(r65, TAU_CURVES, LAST_YEAR, YEAR_END(2));

%% ============================================================================
%  LOCAL FUNCTIONS
%% ============================================================================

function ms = decluster_gk(T)
% Gardner and Knopoff (1974) space-time windows (Eqs. 1 and 2 of the paper).
% Events are processed in decreasing magnitude; smaller events inside the
% window of a larger event are removed as dependent events.
    T  = sortrows(T, {'Year','Month','Day'});
    tt = datenum(T.Year, T.Month, T.Day);
    [~, ord] = sort(T.Mw, 'descend');
    n   = height(T);
    dep = false(n, 1);
    for a = 1:n
        i = ord(a);
        if dep(i), continue; end
        r_win = 10^(0.1238*T.Mw(i) + 0.983);
        if T.Mw(i) >= 6.5
            t_win = 10^(0.032*T.Mw(i) + 2.7389);
        else
            t_win = 10^(0.5409*T.Mw(i) - 0.547);
        end
        for j = 1:n
            if j == i || T.Mw(j) >= T.Mw(i), continue; end
            if abs(tt(i) - tt(j)) > t_win, continue; end
            if haversine_km(T.Latitude(i), T.Longitude(i), ...
                            T.Latitude(j), T.Longitude(j)) <= r_win
                dep(j) = true;
            end
        end
    end
    ms = T(~dep, :);
end

function d = haversine_km(lat1, lon1, lat2, lon2)
    d = 2*6371*asin(sqrt(sin(deg2rad((lat2-lat1)/2)).^2 + ...
        cos(deg2rad(lat1)).*cos(deg2rad(lat2)).*sin(deg2rad((lon2-lon1)/2)).^2));
end

function F = fit_distributions(iet, fopts)
% Maximum likelihood estimates of the 14 candidate distributions.
    n    = length(iet);
    slog = @(x) log(max(x, 1e-300));
    F    = struct('name', {}, 'p', {}, 'cdf', {});

    % 1. Exponential
    a = mean(iet);
    F(end+1) = struct('name','Exponential', 'p',a, 'cdf',@(t) 1 - exp(-t./a));

    % 2. Gamma (alpha = scale, beta = shape)
    s = log(mean(iet)) - mean(log(iet));
    b = (3 - s + sqrt((s-3)^2 + 24*s)) / (12*s);
    for it = 1:100
        b_new = b - (log(b) - psi(b) - s) / (1/b - psi(1,b));
        if abs(b_new - b) < 1e-10, break; end
        b = b_new;
    end
    ag = mean(iet)/b; bg = b;
    F(end+1) = struct('name','Gamma', 'p',[ag bg], 'cdf',@(t) gammainc(t./ag, bg));

    % 3. Lognormal (alpha = log-mean, beta = log-SD)
    aln = mean(log(iet));
    bln = sqrt(mean((log(iet) - aln).^2));
    F(end+1) = struct('name','Lognormal', 'p',[aln bln], ...
        'cdf',@(t) 0.5.*(1 + erf((log(t)-aln)./(bln*sqrt(2)))));

    % 4. Weibull (alpha = scale, beta = shape)
    bw = 1.0;
    for it = 1:200
        tb = iet.^bw; S1 = sum(tb.*log(iet)); S2 = sum(tb); S3 = sum(log(iet));
        f  = n/bw + S3 - n.*S1./S2;
        df = -n/bw^2 - n.*(sum(tb.*log(iet).^2).*S2 - S1.^2)./S2.^2;
        bw_new = max(bw - f/df, 1e-6);
        if abs(bw_new - bw) < 1e-10, break; end
        bw = bw_new;
    end
    aw = (sum(iet.^bw)/n)^(1/bw);
    F(end+1) = struct('name','Weibull', 'p',[aw bw], 'cdf',@(t) 1 - exp(-(t./aw).^bw));

    % 5. Levy
    alv = n / sum(1./iet);
    F(end+1) = struct('name','Levy', 'p',alv, 'cdf',@(t) erfc(sqrt(alv./(2.*t))));

    % 6. Maxwell
    amx = sqrt(sum(iet.^2)/(3*n));
    F(end+1) = struct('name','Maxwell', 'p',amx, 'cdf',@(t) erf(t./(sqrt(2).*amx)) ...
        - sqrt(2/pi).*t./amx.*exp(-t.^2./(2.*amx^2)));

    % 7. Pareto (alpha = scale, beta = shape)
    apa = min(iet);
    bpa = n / sum(log(iet./apa));
    F(end+1) = struct('name','Pareto', 'p',[apa bpa], 'cdf',@(t) 1 - (apa./t).^bpa);

    % 8. Rayleigh
    arl = sqrt(sum(iet.^2)/(2*n));
    F(end+1) = struct('name','Rayleigh', 'p',arl, 'cdf',@(t) 1 - exp(-t.^2./(2.*arl^2)));

    % 9. Inverse Gaussian / BPT (alpha = mean, beta = shape)
    aig = mean(iet);
    big = max(n / sum(1./iet - 1./aig), 1e-6);
    F(end+1) = struct('name','Inverse Gaussian', 'p',[aig big], ...
        'cdf',@(t) normcdf(sqrt(big./t).*(t./aig-1)) + ...
                   exp(2.*big./aig).*normcdf(-sqrt(big./t).*(t./aig+1)));

    % 10. Inverse Weibull / Frechet (alpha = scale, beta = shape)
    nll = @(p) -sum(log(abs(p(2))) - log(abs(p(1))) + ...
        (abs(p(2))+1).*log(abs(p(1))./iet) - (abs(p(1))./iet).^abs(p(2)));
    p = fminsearch(nll, [mean(iet), 1.0], fopts);
    aiw = abs(p(1)); biw = abs(p(2));
    F(end+1) = struct('name','Inverse Weibull', 'p',[aiw biw], ...
        'cdf',@(t) exp(-(aiw./t).^biw));

    % 11. Exponentiated exponential (alpha = rate, beta = shape)
    nll = @(p) -sum(log(abs(p(1))) + log(abs(p(2))) - abs(p(1)).*iet + ...
        (abs(p(2))-1).*slog(1-exp(-abs(p(1)).*iet)));
    p = fminsearch(nll, [1/mean(iet), 1.5], fopts);
    aee = abs(p(1)); bee = abs(p(2));
    F(end+1) = struct('name','Exponentiated Exponential', 'p',[aee bee], ...
        'cdf',@(t) (1-exp(-aee.*t)).^bee);

    % 12. Exponentiated Rayleigh (alpha = scale, beta = shape)
    nll = @(p) -sum(log(2) + log(abs(p(2))) + log(iet) - 2.*log(abs(p(1))) ...
        - (iet./abs(p(1))).^2 + (abs(p(2))-1).*slog(1-exp(-(iet./abs(p(1))).^2)));
    p = fminsearch(nll, [sqrt(mean(iet.^2)/2), 0.5], fopts);
    aer = abs(p(1)); ber = abs(p(2));
    F(end+1) = struct('name','Exponentiated Rayleigh', 'p',[aer ber], ...
        'cdf',@(t) (1-exp(-(t./aer).^2)).^ber);

    % 13. Exponentiated Weibull (alpha = scale, beta and gamma = shapes)
    nll = @(p) -sum(log(abs(p(2))) + log(abs(p(3))) - log(abs(p(1))) + ...
        (abs(p(2))-1).*log(iet./abs(p(1))) - (iet./abs(p(1))).^abs(p(2)) + ...
        (abs(p(3))-1).*slog(1-exp(-(iet./abs(p(1))).^abs(p(2)))));
    p = fminsearch(nll, [mean(iet), 1.0, 1.5], fopts);
    aew = abs(p(1)); bew = abs(p(2)); gew = abs(p(3));
    F(end+1) = struct('name','Exponentiated Weibull', 'p',[aew bew gew], ...
        'cdf',@(t) (1-exp(-(t./aew).^bew)).^gew);

    % 14. Generalized Pareto (alpha = scale sigma, beta = shape xi)
    nll = @(p) -sum(-log(abs(p(1))) - (1+1./p(2)).*log(max(1+p(2).*iet./abs(p(1)), 1e-10)));
    p = fminsearch(nll, [mean(iet), 0.1], fopts);
    sgp = abs(p(1)); xgp = p(2);
    if xgp < 0
        F(end+1) = struct('name','Generalized Pareto', 'p',[sgp xgp], ...
            'cdf',@(t) 1 - max(1+xgp.*t./sgp, 0).^(-1./xgp));
    else
        F(end+1) = struct('name','Generalized Pareto', 'p',[sgp xgp], ...
            'cdf',@(t) 1 - (1+xgp.*t./sgp).^(-1./xgp));
    end
end

function F = goodness_of_fit(F, iet)
% Log-likelihood, AIC (Eq. 7) and K-S distance with p-value (Eq. 8).
    n    = length(iet);
    ts   = sort(iet);
    slog = @(x) log(max(x, 1e-300));
    for d = 1:numel(F)
        p = F(d).p;
        switch F(d).name
            case 'Exponential'
                ll = sum(-log(p(1)) - iet./p(1));
            case 'Gamma'
                ll = sum((p(2)-1).*log(iet) - iet./p(1) - p(2).*log(p(1)) - gammaln(p(2)));
            case 'Lognormal'
                ll = sum(-log(iet) - log(p(2)) - 0.5*log(2*pi) - 0.5.*((log(iet)-p(1))./p(2)).^2);
            case 'Weibull'
                ll = sum(log(p(2)) - log(p(1)) + (p(2)-1).*log(iet./p(1)) - (iet./p(1)).^p(2));
            case 'Levy'
                ll = sum(0.5*log(p(1)/(2*pi)) - 1.5.*log(iet) - p(1)./(2.*iet));
            case 'Maxwell'
                ll = sum(log(sqrt(2/pi)) + 2.*log(iet) - 3.*log(p(1)) - iet.^2./(2.*p(1)^2));
            case 'Pareto'
                ll = sum(log(p(2)) + p(2).*log(p(1)) - (p(2)+1).*log(iet));
            case 'Rayleigh'
                ll = sum(log(iet) - 2.*log(p(1)) - iet.^2./(2.*p(1)^2));
            case 'Inverse Gaussian'
                ll = sum(0.5.*log(p(2)./(2.*pi.*iet.^3)) - p(2).*(iet-p(1)).^2./(2.*p(1)^2.*iet));
            case 'Inverse Weibull'
                ll = sum(log(p(2)) - log(p(1)) + (p(2)+1).*log(p(1)./iet) - (p(1)./iet).^p(2));
            case 'Exponentiated Exponential'
                ll = sum(log(p(1)) + log(p(2)) - p(1).*iet + (p(2)-1).*slog(1-exp(-p(1).*iet)));
            case 'Exponentiated Rayleigh'
                ll = sum(log(2) + log(p(2)) + log(iet) - 2*log(p(1)) - (iet./p(1)).^2 + ...
                         (p(2)-1).*slog(1-exp(-(iet./p(1)).^2)));
            case 'Exponentiated Weibull'
                ll = sum(log(p(2)) + log(p(3)) - log(p(1)) + (p(2)-1).*log(iet./p(1)) - ...
                         (iet./p(1)).^p(2) + (p(3)-1).*slog(1-exp(-(iet./p(1)).^p(2))));
            case 'Generalized Pareto'
                ll = sum(-log(p(1)) - (1+1/p(2)).*log(max(1+p(2).*iet./p(1), 1e-10)));
        end
        Ft    = max(min(F(d).cdf(ts), 1-1e-10), 1e-10);
        D     = max(max(abs((1:n)'/n - Ft)), max(abs(Ft - (0:n-1)'/n)));
        z     = D * (sqrt(n) + 0.12 + 0.11/sqrt(n));
        F(d).negLL = -ll;
        F(d).aic   = 2*numel(p) - 2*ll;
        F(d).ksD   = D;
        F(d).ksP   = ks_p_asymptotic(z);
    end
end

function p = ks_p_asymptotic(z)
% Kolmogorov asymptotic p-value, P(K > z).
    if z <= 0, p = 1; return; end
    p = 0;
    for k = 1:100
        term = 2 * (-1)^(k-1) * exp(-2*k^2*z^2);
        p = p + term;
        if abs(term) < 1e-10, break; end
    end
    p = max(min(p, 1), 0);
end

function F = parameter_uncertainty(F, iet)
% Asymptotic standard deviations (ASD) and 95% confidence intervals
% (Eqs. 4-6 of the paper). NaN = not reported in Tables 3-4.
    n = length(iet);
    for d = 1:numel(F)
        p  = F(d).p;
        se = nan(size(p));
        lo_cap = -inf(size(p));
        switch F(d).name
            case 'Exponential'
                se = p(1)/sqrt(n);
            case 'Gamma'
                FIM = [p(2)/p(1)^2, -1/p(1); -1/p(1), psi(1,p(2))];
                V = inv(FIM)/n; se = sqrt(diag((V+V')/2))';
            case 'Lognormal'
                se = [p(2)/sqrt(2*n), p(2)/sqrt(n)];
            case 'Weibull'
                I12 = -(1 + psi(1))/p(1);
                FIM = [p(2)^2/p(1)^2, I12; I12, (psi(1,1) + psi(2)^2)/p(2)^2];
                V = inv(FIM)/n; se = sqrt(diag((V+V')/2))';
            case 'Levy'
                se = p(1)*sqrt(2/n);
            case 'Maxwell'
                se = p(1)/sqrt(6*n);
            case 'Pareto'                                  % Quandt (1964)
                c  = min(iet); nb = n*p(2);
                se = [sqrt((c^2*nb)/((nb-2)*(nb-1)^2)), (p(2)*n)/((n-2)*sqrt(n-3))];
            case 'Rayleigh'
                se = p(1)/(2*sqrt(n));
            case 'Inverse Gaussian'
                se = [2*p(2)/sqrt(n), sqrt(p(1)^3/(n*p(2)))];
                lo_cap = [-inf, 0];                        % beta must be positive
            case 'Inverse Weibull'
                I12 = (1 + psi(1))/p(1);
                FIM = [p(2)^2/p(1)^2, I12; I12, (psi(1,1) + psi(2)^2)/p(2)^2];
                V = inv(FIM)/n; se = sqrt(diag((V+V')/2))';
            case 'Generalized Pareto'                      % Smith (1985)
                s = p(1); x = p(2);
                if x > -0.5
                    FIM = [2/((1+x)*(1+2*x)), 1/(s*(1+x)*(1+2*x)); ...
                           1/(s*(1+x)*(1+2*x)), 1/(s^2*(1+2*x))];
                    V = inv(n*FIM); V = (V+V')/2;
                    se = [sqrt(V(2,2)), sqrt(V(1,1))];     % [sigma, xi]
                end
        end
        F(d).se = se;
        F(d).lo = max(p - 1.96*se, lo_cap);
        F(d).hi = p + 1.96*se;
    end
end

function cp = cond_prob(cdf, tau, nu)
% Conditional probability of Eq. (9): P(X <= tau+nu | X > tau).
    Ftn = max(0, min(1, real(cdf(tau + nu))));
    Ft  = max(0, min(1, real(cdf(tau))));
    if 1 - Ft <= 1e-10, cp = 1; return; end
    cp = max(0, min(1, (Ftn - Ft)/(1 - Ft)));
end

%% ---- Table printing ---------------------------------------------------------

function print_table1(ms)
    fprintf('\nTable 1: Large earthquakes (Mw >= 7.0) after declustering\n');
    fprintf('%6s %6s %6s %5s %10s %10s %6s\n', 'Sr.No','Year','Month','Day','Lat(N)','Long(E)','Mw');
    for i = 1:height(ms)
        fprintf('%6d %6d %6d %5d %10.3f %10.3f %6.1f\n', i, ms.Year(i), ms.Month(i), ...
            ms.Day(i), ms.Latitude(i), ms.Longitude(i), ms.Mw(i));
    end
end

function print_table2(x7, x65)
    fprintf('\nTable 2: Descriptive statistics of interoccurrence times\n');
    fprintf('%-38s %12s %12s\n', 'Measure', 'Mw >= 7.0', 'Mw >= 6.5');
    st = @(x) [numel(x), mean(x), std(x,0), std(x,0)/mean(x), skewness(x), ...
               kurtosis(x)-3, min(x), max(x)];
    a = st(x7); b = st(x65);
    lab = {'Number of interoccurrence times (N)', 'Mean (years)', ...
           'Standard deviation (years)', 'Coefficient of variation', 'Skewness', ...
           'Excess kurtosis', 'Minimum (years)', 'Maximum (years)'};
    fprintf('%-38s %12d %12d\n', lab{1}, a(1), b(1));
    for i = 2:numel(lab)
        fprintf('%-38s %12.4f %12.4f\n', lab{i}, a(i), b(i));
    end
end

function print_table34(r, ttl)
    order = {'Exponential','Gamma','Lognormal','Weibull','Levy','Maxwell','Pareto', ...
             'Rayleigh','Inverse Gaussian','Inverse Weibull','Generalized Pareto', ...
             'Exponentiated Exponential','Exponentiated Rayleigh','Exponentiated Weibull'};
    sym = {'alpha','beta','gamma'};
    fprintf('\n%s\n', ttl);
    fprintf('%-28s %-6s %10s %10s   %s\n', 'Reference model', '', 'Estimate', 'ASD', '95% CI');
    for k = 1:numel(order)
        d = find(strcmp({r.F.name}, order{k}));
        for j = 1:numel(r.F(d).p)
            if j == 1, nm = order{k}; else, nm = ''; end
            if isnan(r.F(d).se(j))
                fprintf('%-28s %-6s %10.4f %10s   %s\n', nm, sym{j}, r.F(d).p(j), '-', '-');
            else
                fprintf('%-28s %-6s %10.4f %10.4f   %.4f to %.4f\n', nm, sym{j}, ...
                    r.F(d).p(j), r.F(d).se(j), r.F(d).lo(j), r.F(d).hi(j));
            end
        end
    end
end

function print_table56(r, ttl)
    fprintf('\n%s\n', ttl);
    fprintf('%-28s %10s %10s %10s %10s\n', 'Distribution', '-lnL', 'AIC', 'K-S D', 'p-value');
    for d = r.order
        fprintf('%-28s %10.3f %10.3f %10.4f %10.4f\n', r.F(d).name, r.F(d).negLL, ...
            r.F(d).aic, r.F(d).ksD, r.F(d).ksP);
    end
end

function print_table78(r, taus, nus, last_year, ttl)
    best = r.F(r.order(1));                              % lowest K-S distance
    fprintf('\n%s\n', ttl);
    fprintf('%-6s', 'nu');
    for t = taus, fprintf('%9s', sprintf('%d(%d)', t, last_year + t)); end
    fprintf('\n');
    for v = nus
        fprintf('%-6d', v);
        for t = taus
            cp = cond_prob(best.cdf, t, v);
            if cp >= 0.99, fprintf('%9s', '>0.99'); else, fprintf('%9.2f', cp); end
        end
        fprintf('\n');
    end
end

%% ---- Figures (plotting code from the original scripts) ---------------------

function set_style(axes_lw, line_lw)
% Default graphics settings used in the original scripts.
    set(groot, 'DefaultFigureRenderer', 'painters');
    set(groot, 'defaultAxesFontSize',   11);
    set(groot, 'defaultAxesFontWeight', 'bold');
    set(groot, 'defaultAxesLineWidth',  axes_lw);
    set(groot, 'defaultLineLineWidth',  line_lw);
    set(groot, 'defaultTextFontWeight', 'bold');
end

function figure2_cumulative(ms_PRIMARY, MAGNITUDE_THRESHOLD)
% Figure 2: cumulative number of declustered earthquakes (declustering_02.m).
    set_style(1.3, 1.8);
    figure('Position', [50 50 1000 550]);

    ms_sorted = sortrows(ms_PRIMARY, {'Year','Month','Day'});
    yrs = ms_sorted.Year;
    n_events = height(ms_sorted);
    cum = (1:n_events)';
    mw_sorted = ms_sorted.Mw;

    p = polyfit(yrs, cum, 1);
    fit_line = polyval(p, yrs);

    ss_res = sum((cum - fit_line).^2);
    ss_tot = sum((cum - mean(cum)).^2);
    r2 = 1 - ss_res / ss_tot;

    hold on;
    h_obs = scatter(yrs, cum, 50, mw_sorted, ...
        'filled', 'MarkerEdgeColor', 'k', 'LineWidth', 0.5, ...
        'DisplayName', 'Mainshocks');
    h_fit = plot(yrs, fit_line, '--', ...
        'LineWidth', 2.5, 'Color', [0.84 0.15 0.16], ...
        'DisplayName', sprintf('Linear fit (R^2 = %.3f)', r2));

    equation_str = sprintf('y = %.3f x % +.3f', p(1), p(2));
    text(0.05, 0.85, {'\bf{Regression Equation:}', ['\it{' equation_str '}']}, ...
        'Units', 'normalized', ...
        'FontSize', 11, ...
        'Color', [0 0 0], ...
        'BackgroundColor', [1 1 1 0.7], ...
        'EdgeColor', [0 0 0], ...
        'LineWidth', 1.2);
    hold off;

    colormap(parula);
    cb = colorbar;
    cb.Label.String = 'Magnitude (M_w)';
    cb.Label.FontWeight = 'bold';
    cb.LineWidth = 1.3;
    clim([min(ms_PRIMARY.Mw) max(ms_PRIMARY.Mw)]);

    xlabel('Time (Year)', 'FontWeight', 'bold', 'FontSize', 12);
    ylabel(['Cumulative Number of M ≥', num2str(MAGNITUDE_THRESHOLD, '%0.1f'), ' Events'], ...
        'FontWeight', 'bold', 'FontSize', 12);

    legend([h_obs, h_fit], 'Location', 'southeast', ...
        'FontSize', 11, 'FontWeight', 'bold', 'Box', 'on', 'LineWidth', 1.3);

    grid on; box on;
    set(gca, 'XMinorTick', 'on', 'YMinorTick', 'on', 'LineWidth', 1.3, 'FontWeight', 'bold');
end

function figure3_ks_plot(r)
% Figure 3: CDFs of all 14 distributions against the ECDF
% (distribution_fitting_05.m, figure 05b).
    set_style(1.5, 2.0);
    iet     = r.iet;
    n       = numel(iet);
    n_dists = numel(r.F);
    iet_s   = sort(iet);
    ecdf_y  = (1:n)' / n;
    t_range = linspace(0.001, max(iet)*1.3, 600);
    cmap    = lines(n_dists);

    figure('Position',[50 50 1200 620]);
    stairs(iet_s, ecdf_y, 'k-', 'LineWidth',2.0, 'DisplayName','Empirical CDF');
    hold on;
    for d = 1:n_dists
        try
            y = r.F(d).cdf(t_range);
            y = max(min(y,1),0);
            y(~isfinite(y)) = NaN;
            plot(t_range, y, '--', 'Color',cmap(d,:), 'LineWidth',2.0, ...
                 'DisplayName', r.F(d).name);
        catch
        end
    end
    hold off;

    xlabel('Interevent Time (years)',          'FontWeight','bold','FontSize',12);
    ylabel('Cumulative Distribution Function', 'FontWeight','bold','FontSize',12);
    legend('Location','southeast','FontSize',8,'NumColumns',2,'Box','on','LineWidth',1.2);
    ylim([0 1.05]);
    apply_axis_style(gca);
end

function apply_axis_style(ax)
% Bold outlines, bold text, minor ticks (no minor grid), major grid only.
    set(ax, ...
        'FontSize',        14, ...
        'FontWeight',      'bold', ...
        'LineWidth',       2.0, ...
        'TickLength',      [0.015 0.008], ...
        'XMinorTick',      'on', ...
        'YMinorTick',      'on', ...
        'XGrid',           'on', ...
        'YGrid',           'on', ...
        'XMinorGrid',      'off', ...
        'YMinorGrid',      'off', ...
        'GridLineStyle',   '-', ...
        'GridAlpha',       0.25, ...
        'Box',             'on');
    ax.XAxis.FontWeight = 'bold';
    ax.YAxis.FontWeight = 'bold';
    ax.LineWidth = 2.0;
end

function figure4_pairwise(r)
% Figure 4: best distribution against the next four
% (model_selection_07.m, figure 07b).
    set_style(1.5, 2.0);
    iet        = r.iet;
    n          = numel(iet);
    dist_names = {r.F.name};
    cdf_cell   = {r.F.cdf};
    iet_sorted = sort(iet);
    ecdf_vals  = (1:n)' ./ n;
    t_range    = linspace(0.001, max(iet)*1.3, 600);
    top5_idx   = r.order(1:5);

    pairs = { ...
        top5_idx(1), top5_idx(2), 'a';
        top5_idx(1), top5_idx(3), 'b';
        top5_idx(1), top5_idx(4), 'c';
        top5_idx(1), top5_idx(5), 'd'};
    n_pairs = size(pairs, 1);

    C_ECDF  = [0.05 0.50 0.05];
    C_BEST  = [0.85 0.10 0.10];
    C_OTHER_LIST = [ ...
        0.05 0.30 0.85;
        0.50 0.15 0.70;
        0.00 0.65 0.75;
        0.90 0.60 0.00];
    C_NAMED = containers.Map( ...
        {'Weibull',          'Generalized Pareto'}, ...
        {[0.10 0.10 0.10],   [0.80 0.00 0.60]}, ...
        'UniformValues', false);
    LW_ECDF  = 1.6;
    LW_BEST  = 1.2;
    LW_OTHER = 3.2;

    X_GRID_STEP = 1;
    Y_GRID_STEP = 0.2;
    x_max   = max(iet_sorted)*1.06;
    x_ticks = 0:X_GRID_STEP:floor(x_max);
    y_ticks = 0:Y_GRID_STEP:1;

    fig_W = 920;
    fig_H = 720;
    left_margin = 0.09;
    right_margin = 0.03;
    top_margin = 0.08;
    bottom_margin = 0.08;
    h_gap = 0.06;
    v_gap = 0.08;
    n_cols = 2;
    n_rows = 2;
    ax_w = (1-left_margin-right_margin-(n_cols-1)*h_gap)/n_cols;
    ax_h = (1-top_margin-bottom_margin-(n_rows-1)*v_gap)/n_rows;

    fig7b = figure('Position',[60 60 fig_W fig_H],'Name','07b_KS_pairwise_modified',...
                   'NumberTitle','off','Color','w');
    for p = 1:n_pairs
        col = mod(p-1, n_cols);
        row = floor((p-1) / n_cols);
        x0  = left_margin + col*(ax_w+h_gap);
        y0  = 1 - top_margin - (row+1)*ax_h - row*v_gap;
        ax  = axes('Parent',fig7b,'Position',[x0 y0 ax_w ax_h]); %#ok<LAXES>

        dBest  = pairs{p,1};
        dOther = pairs{p,2};

        if isKey(C_NAMED, dist_names{dOther})
            C_this = C_NAMED(dist_names{dOther});
        else
            C_this = C_OTHER_LIST(p,:);
        end

        try, FBest = max(min(cdf_cell{dBest}(t_range),1),0); FBest(~isfinite(FBest)) = NaN;
        catch, FBest = nan(size(t_range)); end
        try, FOther = max(min(cdf_cell{dOther}(t_range),1),0); FOther(~isfinite(FOther)) = NaN;
        catch, FOther = nan(size(t_range)); end

        hE = stairs(ax,iet_sorted,ecdf_vals,'Color',C_ECDF,'LineWidth',LW_ECDF,...
               'DisplayName','Empirical Distribution Function');
        hold(ax,'on');
        hO = plot(ax,t_range,FOther,'Color',C_this,'LineWidth',LW_OTHER,...
             'LineStyle','--','DisplayName',dist_names{dOther});
        hB = plot(ax,t_range,FBest,'Color',C_BEST,'LineWidth',LW_BEST,...
             'LineStyle','-','DisplayName',[dist_names{dBest} ' (Best)']);
        hold(ax,'off');

        xlabel(ax,'Time interval between successive events (years)',...
               'FontWeight','bold','FontSize',9.5);
        ylabel(ax,'Cumulative distribution function','FontWeight','bold','FontSize',9.5);
        lgd = legend(ax,[hE hB hO],'Location','southeast','FontSize',8.5,'Box','on','LineWidth',1.0);
        lgd.FontWeight = 'bold';
        ylim(ax,[0 1.05]);
        xlim(ax,[0 x_max]);
        set(ax,'FontSize',9,'FontWeight','bold','LineWidth',1.4,'Box','on',...
               'XTick',x_ticks,'YTick',y_ticks,...
               'XGrid','on','YGrid','on','XMinorTick','on','YMinorTick','on',...
               'XMinorGrid','off','YMinorGrid','off','GridAlpha',0.25,...
               'TickLength',[0.015 0.008]);
        ax.XAxis.FontWeight = 'bold';
        ax.YAxis.FontWeight = 'bold';
    end
end

function figure56_conditional(r, tau_curves, LAST_YEAR, year_end)
% Figures 5-6: conditional probability curves for the four distributions
% with the lowest K-S distance (hazard_curves_08.m, figure 08a).
    set_style(1.5, 2.0);
    top4 = r.order(1:4);
    years_plot = (LAST_YEAR+1):year_end;

    TAU_COLORS = [
        0.05 0.40 0.75;
        0.00 0.62 0.45;
        0.90 0.62 0.00;
        0.84 0.10 0.10;
        0.55 0.00 0.55;
        0.20 0.65 0.85;
        0.75 0.35 0.05;
        0.40 0.40 0.40];

    figure('Position',[30 30 1400 900],'Color','w');

    pos1 = [0.07, 0.56, 0.40, 0.40];
    pos2 = [0.52, 0.56, 0.40, 0.40];
    pos3 = [0.07, 0.07, 0.40, 0.40];
    pos4 = [0.52, 0.07, 0.40, 0.40];
    positions = {pos1, pos2, pos3, pos4};

    for k = 1:4
        ax = axes('Position', positions{k}); %#ok<LAXES>
        hold on;
        for ti = 1:length(tau_curves)
            tau_t = tau_curves(ti);
            prob = NaN(size(years_plot));
            for i = 1:length(years_plot)
                T = years_plot(i) - LAST_YEAR;
                if T > tau_t, prob(i) = cond_prob(r.F(top4(k)).cdf, tau_t, T - tau_t); end
            end
            prob = real(prob);
            plot(years_plot, prob, '-', 'Color', TAU_COLORS(ti,:), 'LineWidth', 2.0, ...
                 'DisplayName', sprintf('\\tau = %d yr', tau_curves(ti)));
        end
        hold off;

        title(r.F(top4(k)).name, 'FontWeight','bold', 'FontSize',20, 'Interpreter','tex');
        xlabel('Year', 'FontWeight','bold', 'FontSize',20, 'Interpreter','tex');
        ylabel('Conditional Probability', 'FontWeight','bold', 'FontSize',20, 'Interpreter','tex');

        ylim([0 1.02]);
        xlim([LAST_YEAR+1 year_end]);
        yticks(0:0.1:1);
        yticklabels(compose('%.1f', 0:0.1:1));
        x0 = ceil((LAST_YEAR+1)/10)*10;
        xticks(x0:10:year_end);

        lgd = legend('show', 'Location','southeast', 'FontSize',14, 'Box','on', 'NumColumns',1);
        lgd.Title.String = 'Elapsed time \tau';
        lgd.Title.FontWeight = 'bold';

        ax_style(ax);
    end
end

function ax_style(ax)
    set(ax,'FontSize',12,'FontWeight','bold','LineWidth',1.3,...
           'TickLength',[0.012 0.006],'XMinorTick','on','YMinorTick','on',...
           'XGrid','on','YGrid','on','XMinorGrid','off','YMinorGrid','off',...
           'GridAlpha',0.22,'Box','on');
    ax.XAxis.FontWeight = 'bold';
    ax.YAxis.FontWeight = 'bold';
end
